package controller

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"model"
	"net/http"
)

func GetHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		r.ParseForm()
		ids := r.Form["id"]
		if len(ids) <= 0 {                                        //read request
			fmt.Println("Get|id is emtpy ")
			writeFailureResponse(w, "error")
			return
		}

		if per, err := model.GetPerson(ids[0]); err != nil {      //get person
			writeFailureResponse(w, err.Error())
		} else {
			out, _ := json.Marshal(*per)                          //marshal to json
			fmt.Println("GetSuccess: ", string(out))
			writeSuccessResponse(w, string(out))
		}
	} else {                                                      //error method
		writeFailureResponse(w, "Not support method")
	}
}

func GetAllHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method == "GET" {
		per := model.GetAllPerson()                               //get all person
		fmt.Printf("GetAllHandler %v", string(per))
		writeSuccessResponse(w, per)
	} else {
		writeFailureResponse(w, "Not support method")
	}
}

func PostHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		data, _ := ioutil.ReadAll(r.Body)                         //read body to data
		fmt.Println("PostRead: ", string(data))
		per := &model.Person{}

		if err := json.Unmarshal(data, per); err != nil {         //unmarshal data to per
			writeFailureResponse(w, err.Error())
		} else {
			if err := model.PostPerson(per); err != nil {         //post per
				writeFailureResponse(w, err.Error())
				return
			}

			out, _ := json.Marshal(*per)                          //marshal per
			fmt.Println("PostSuccess: ", string(out))
			writeSuccessResponse(w, string(out))
		}
	} else {
		writeFailureResponse(w, "Not support method")
	}
}

func DelHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "DELETE" {
		data, _ := ioutil.ReadAll(r.Body)                          //read body to data
		fmt.Println("DelRead: ", string(data))
		per := &model.Person{}
		if err := json.Unmarshal(data, per); err != nil {          //unmarshal data to per
			writeFailureResponse(w, err.Error())
		} else {
			if err := model.DelPerson(per.ID); err != nil {        //del per.ID
				writeFailureResponse(w, err.Error())
				return
			}
			out, _ := json.Marshal(*per)                           //marshal per
			fmt.Println("DelSuccess: ", string(out))   //if per.ID exist
			writeSuccessResponse(w, string(out))
		}
	} else {
		writeFailureResponse(w, "Not support method")
	}
}

func writeSuccessResponse(w http.ResponseWriter, data interface{}) {   //output success with json
	JsonStatus, _ := json.Marshal(&model.Status{          //marshal JsonStatus
		EnCode: model.EnCode_Success,
		Msg:    "",
		Data:   &data,
	})
	w.Write(JsonStatus)                                   //output
}

func writeFailureResponse(w http.ResponseWriter, errStr string) {      //output failure with json
	JsonStatus, _ := json.Marshal(&model.Status{         //marshal JsonStatus
		EnCode: model.EnCode_Failure,
		Msg:    errStr,
	})
	w.Write(JsonStatus)                                  //output
}
