package main

import (
	"controller"
	"model"
	"net/http"
)

func main() {
//initial map data
	model.User["1"] = &model.Person{ID: "1", Name: "张三", Address: &model.Address{City: "十堰", Province: "湖北省"}}
	model.User["2"] = &model.Person{ID: "2", Name: "李四", Address: &model.Address{City: "襄樊", Province: "湖北省"}}
	model.User["3"] = &model.Person{ID: "3", Name: "王五", Address: &model.Address{City: "深圳", Province: "广东省"}}
//initial router
	http.HandleFunc("/all", controller.GetAllHandler)
	http.HandleFunc("/get", controller.GetHandler)
	http.HandleFunc("/post", controller.PostHandler)
	http.HandleFunc("/del", controller.DelHandler)
//set listen port
	if err := http.ListenAndServe(":9000", nil); err != nil {
		panic("error: " + err.Error())
	}
}
