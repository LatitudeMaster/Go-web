package model

import (
	"encoding/json"
	"errors"
	"fmt"
)

func GetPerson(id string) (*Person, error) {
	if id == "" {                                                 //if id is ""
		return nil, errors.New("person id is empty")
	}

	if _, exist := User[id]; !exist {                             //if not exist
		return nil, errors.New(fmt.Sprintf("person (%s) is not exist", id))
	}

	return User[id], nil                                          //return User[id]
}

func GetAllPerson() string {
	out, _ := json.Marshal(User)                                  //marshal User to out
	if out == nil {
		return fmt.Sprintln("Users are not exist")
	}

	fmt.Println("Getall: ", string(out))

	return string(out)                                            //return string(out)
}

func PostPerson(per *Person) error {
	if per == nil {                                               //if per is not exist
		return errors.New("data is nil")
	}

	if per.ID == "" {                                             //if per.ID is ""
		return errors.New("person id is empty")
	}

	if _, exist := User[per.ID]; exist {                          //if per.ID is exist
		return errors.New(fmt.Sprintf("person (%s) is exist", per.ID))
	}

	User[per.ID] = per                                            //input per to User[per.ID]

	return nil
}

func DelPerson(id string) error {
	if id == "" {                                                 //if id is ""
		return errors.New("person id is empty")
	}

	if _, exist := User[id]; !exist {                             //if User[id] is not exist
		return errors.New(fmt.Sprintf("person (%s) not exist", id))
	}

	delete(User, id)                                              //delete  User[id]

	return nil
}
