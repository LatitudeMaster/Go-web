package model

const (                                  //Encode status
	EnCode_Success = 0
	EnCode_Failure = 1
)

type Status struct {                     //status
	EnCode int
	Msg    string
	Data   interface{}
}

type Person struct {
	ID      string   `json:"id"`
	Name    string   `json:"name"`
	Address *Address `json:"address"`
}
type Address struct {
	City     string `json:"city"`
	Province string `json:"province"`
}

var User map[string]*Person            //a map of Person

func init() {
	User = make(map[string]*Person)    //create cache
}
